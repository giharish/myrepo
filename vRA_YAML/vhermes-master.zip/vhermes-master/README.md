# vHermes

VMware TMM 

Leverage vRealize Automation’s Action Based eXtensibility (ABX), Event Broker Service (EBS) & APIs for Email customized notifications