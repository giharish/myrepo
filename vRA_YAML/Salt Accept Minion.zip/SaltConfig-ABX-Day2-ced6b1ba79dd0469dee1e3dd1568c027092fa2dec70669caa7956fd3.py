def handler(context, inputs):
    import paramiko
    host = inputs["hostname"]
    user = inputs["username"]
    passwd = inputs["password"]
    name = inputs["name"]
    
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=user, password=passwd, look_for_keys=False)
    command = "sudo salt-key -y -A " + name + " > /tmp/salt.out"
    print(command)
    (stdin, stdout, stderr) = client.exec_command(command)
    for line in stdout:
        print(line.strip('\n'))
    client.close()
    